#Python Midterm Questions
#Term 2 Daniel Embley

category for questions

question
answer1()
answer2()
answer3()
answer4()
the answer is because()


question
answer1
answer2
answer3
answer4
the answer is because
why

question
answer1
answer2
answer3
answer4
the answer is because
why

question
answer1
answer2
answer3
answer4
the answer is because
why


