puzzle = "NSSPFLOWCHARTSABNPHODNVCQJFJTIYZYQKWRAODZOSRMYWTSSMNRXADUYFPSOHJFPTIBTRTNTOBOOLEANALEEPTIRRENJTPSBITTUAMTHAXJNORLSIUTXEAOKNBMGOETMRTEQUWKYGIKHSZENPRPLTINDENTERRORRROAJDIVFAEFYIOOIOSTRINGSRNYRERNPKBREAKNKYDUTQTSWVFUNCTIONINPUT"
puzzle.replace(" ", "")
print(len(puzzle))






def display_wordsearch(p):
    grid = str.format("""
   0  1  2  3  4  5  6  7  8  9  10 11 12 13 14
  ----------------------------------------------
0 |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
1 |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
2 |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
3 |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
4 |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
5 |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
6 |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
7 |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
8 |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
9 |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
10|{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
11|{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
12|{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
13|{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
14|{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |{} |
  ----------------------------------------------
""",p[0],p[1],p[2],p[3],p[4],p[5],p[6],p[7],p[8],p[9],p[10],p[11],p[12],p[13],p[14],p[15],p[16],
p[17],p[18],p[19],p[20],p[21],p[22],p[23],p[24],p[25],p[26],p[27],p[28],p[29],p[30],p[31],p[32],p[33],p[34],p[35],p[36],
p[37],p[38],p[39],p[40],p[41],p[42],p[43],p[44],p[45],p[46],p[47],p[48],p[49],p[50],p[51],p[52],p[53],p[54],p[55],p[56],
p[57],p[58],p[59],p[60],p[61],p[62],p[63],p[64],p[65],p[66],p[67],p[68],p[69],p[70],p[71],p[72],p[73],p[74],p[75],p[76],
p[77],p[78],p[79],p[80],p[81],p[82],p[83],p[84],p[85],p[86],p[87],p[88],p[89],p[90],p[91],p[92],p[93],p[94],p[95],p[96],
p[97],p[98],p[99],p[100],p[101],p[102],p[103],p[104],p[105],p[106],p[107],p[108],p[109],p[110],p[111],p[112],p[113],p[114],p[115],p[116],
p[117],p[118],p[119],p[120],p[121],p[123],p[124],p[125],p[126],p[127],p[128],p[129],p[130],p[131],p[132],p[133],p[134],p[135],p[136],p[137],
p[138],p[139],p[140],p[141],p[142],p[143],p[144],p[145],p[146],p[147],p[148],p[149],p[150],p[151],p[152],p[153],p[154],p[155],p[156],p[157],
p[158],p[159],p[160],p[161],p[162],p[163],p[164],p[165],p[166],p[167],p[168],p[169],p[170],p[171],p[172],p[173],p[174],p[175],p[176],p[177],
p[178],p[179],p[180],p[181],p[182],p[183],p[184],p[185],p[186],p[186],p[187],p[188],p[189],p[190],p[191],p[192],p[193],p[193],p[194],p[195],
p[196],p[197],p[198],p[199],p[200],p[201],p[202],p[203],p[204],p[205],p[206],p[207],p[208],p[209],p[210],p[211],p[212],p[213],p[214],p[215],
p[216],p[217],p[218],p[219],p[220],p[222],p[223],p[224])
    print(grid)
display_wordsearch(puzzle)


import random
words = ["List","Input","Output","Loops","Strings","Function","Python","Binary","Range","Variables",
         "Print","SyntaxError","IndentError","Return","Break","FlowChart","Import","Datetime","Striftime","Boolean"]
questions = ["What do you get when you wrap your data in [] brackets","A function that gets input from the user is _____",
             "A function that displays or gives feedback to the user is _____","How do you repeat of block of code?",
             "What do you get when you wrap your date in " " (quotation marks)","I am a block of organized, reusable code. What am I?","Python is a coding _______",
             "______ is a serious of 1's and 0's","I can pull numbers from a _____ of numbers","A _______ contains, and is a date type","I am used to display output",
             "I show up when you break a set rules that defines how a pthon program will be written and interpreted","What makes your code not run when you have an unexpectedindent",
             "A ______ statement ends the execution of the function call and ______ the result","A _____ statement terminates the loop containing the _____ ",
             "I am used to plan out what code will do. What am I?","I am used to ______ a module to access script from another python file","I am a comibnations of date and time",
             "The ______() method returns a string representing date and time using date, time, or datetime object","What data type has only 2 options/solutions"]

def random_question(words, questions):
    copyquest = questions
    copyword = words
    picked = random.randint(0,len(words)-1)
    asked_words = words.pop(picked)
    asked_question = questions.pop(picked)    
    return asked_question, asked_words
while words:
    asked_question, asked_words = random_question(words, questions)

    print(asked_words,asked_question)


def get_word(puzzle):
    num=[]
    placement= ""
    find= input("Input your placement for the word your looking for (in order)")
    for i in find:
        if i != ",":
            placement = placement + i
        else:
            if placement.isdigit():
                num.append(int(placement))
                placement= ""
    num.append(int(placement))
    if num[0]+1 == num[1]  or num[0]-1 == num[1] or num[0]+15 == num[1] or num[0]-15 == num[1]\
          or num[0]+16 == num[1] or num[0]+14 == num[1] or num[0]-16 == num[1] or num[0]-14 == num[1]:
        print("Good job")
    else:
        print("Try again, make sure it is enterted correctly")

    while num:
        x = num.pop(0)
        placement = placement + puzzle[x]
    print(placement)
    return placement

get_word(puzzle)


         
input()
